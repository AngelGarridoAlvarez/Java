package app.ejemplo;

public interface Volador {
	
	public abstract void volar();

}
