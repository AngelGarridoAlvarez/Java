package app.ejemplo;

public interface ProductoVenta {
	
	public double getPrecio();

}
